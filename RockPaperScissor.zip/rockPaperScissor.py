#importing necessary modules:-
import random
import sys

#Playing Multiple Rounds:-
while True:

	#Taking user input
	user_action=input("\nEnter a choice  (Rock  Paper  Scissors)\n\n").strip().lower()

	#Checking if user input is from given choices only:-
	if(user_action !='rock' and user_action !='paper' and user_action!='scissors'):
		print('\nOOPS!!!!! Invalid Input\nGood Bye')
		sys.exit()

	#Computer's choice:-
	options=['Rock','Paper','Scissors']
	computer_action = random.choice(options).lower()

	#printing Computer's and Player's choice:-
	print(f'\nYou chose {user_action}\n\nComputer chose {computer_action}\n')

	#Determining a winner:-
	if user_action == computer_action:
		print(f"Both players selected {user_action}. It's a tie!")
	elif user_action == "rock":
		if computer_action == "scissors":
			print("Rock smashes scissors! You win!")
		else:
			print("Paper covers rock! You lose.")
	elif user_action == "paper":
		if computer_action == "rock":
			print("Paper covers rock! You win!")
		else:
			print("Scissors cuts paper! You lose.")
	elif user_action == "scissors":
		if computer_action == "paper":
			print("Scissors cuts paper! You win!")
		else:
			print("Rock smashes scissors! You lose.")

	#Asking for a Rematch:-
	play_again = input("\nPlay again? (y/n): ")
	if play_again.lower() != "y":
		print("\nIt was a great game\nSee you soon :)")
		break
